const Me = imports.misc.extensionUtils.getCurrentExtension();
const Utils = Me.imports.utils;
const { Clutter, Gio, St } = imports.gi;
const { PopupMenuItem, PopupSwitchMenuItem } = imports.ui.popupMenu;
const { Button } = imports.ui.panelMenu;
const GLib = imports.gi.GLib;
var Indicator = class Indicator {
    constructor(ext) {
        this.button = new Button(0.0, _("Pop Shell Settings"));
        ext.button = this.button;
        ext.button_gio_icon_auto_on = Gio.icon_new_for_string(`${Me.path}/icons/pop-shell-auto-on-symbolic.svg`);
        ext.button_gio_icon_auto_off = Gio.icon_new_for_string(`${Me.path}/icons/pop-shell-auto-off-symbolic.svg`);
        let button_icon_auto_on = new St.Icon({
            gicon: ext.button_gio_icon_auto_on,
            style_class: "system-status-icon",
        });
        let button_icon_auto_off = new St.Icon({
            gicon: ext.button_gio_icon_auto_off,
            style_class: "system-status-icon",
        });
        if (ext.settings.tile_by_default()) {
            this.button.icon = button_icon_auto_on;
        }
        else {
            this.button.icon = button_icon_auto_off;
        }
        this.button.add_actor(this.button.icon);
        let bm = this.button.menu;
        this.toggle_tiled = tiled(ext);
        this.toggle_active = toggle(_("Show Active Hint"), ext.settings.active_hint(), (toggle) => {
            ext.settings.set_active_hint(toggle.state);
        });
        this.entry_gaps = number_entry(_("Gaps"), ext.settings.gap_inner(), (value) => {
            ext.settings.set_gap_inner(value);
            ext.settings.set_gap_outer(value);
        });
        this.border_radius = number_entry(_("Active Border Radius"), {
            value: ext.settings.active_hint_border_radius(),
            min: 0,
            max: 30
        }, (value) => {
            ext.settings.set_active_hint_border_radius(value);
        });
        bm.addMenuItem(this.toggle_tiled);
        if (!Utils.is_wayland()) {
            this.toggle_titles = show_title(ext);
            bm.addMenuItem(this.toggle_titles);
        }
        bm.addMenuItem(this.toggle_active);
        bm.addMenuItem(this.border_radius);
        bm.addMenuItem(color_selector(ext, bm));
    }
    destroy() {
        this.button.destroy();
    }
}
function clamp(input, min = 0, max = 128) {
    return Math.min(Math.max(min, input), max);
}
function number_entry(label, valueOrOptions, callback) {
    let value = valueOrOptions, min, max;
    if (typeof valueOrOptions !== 'number')
        ({ value, min, max } = valueOrOptions);
    const entry = new St.Entry({
        text: String(value),
        input_purpose: Clutter.InputContentPurpose.NUMBER,
        x_align: Clutter.ActorAlign.CENTER,
        x_expand: false
    });
    entry.set_style('width: 5em');
    entry.connect('button-release-event', () => {
        return true;
    });
    const text = entry.clutter_text;
    text.set_max_length(2);
    entry.connect('key-release-event', (_, event) => {
        const symbol = event.get_key_symbol();
        const number = symbol == 65293
            ? parse_number(text.text)
            : symbol == 65361
                ? clamp(parse_number(text.text) - 1, min, max)
                : symbol == 65363
                    ? clamp(parse_number(text.text) + 1, min, max)
                    : null;
        if (number !== null) {
            text.set_text(String(number));
        }
    });
    const create_icon = (icon_name) => {
        return new St.Icon({ icon_name, icon_size: 16 });
    };
    entry.set_primary_icon(create_icon('value-decrease'));
    entry.connect('primary-icon-clicked', () => {
        text.set_text(String(clamp(parseInt(text.get_text()) - 1, min, max)));
    });
    entry.set_secondary_icon(create_icon('value-increase'));
    entry.connect('secondary-icon-clicked', () => {
        text.set_text(String(clamp(parseInt(text.get_text()) + 1, min, max)));
    });
    text.connect('text-changed', () => {
        const input = text.get_text();
        let parsed = parseInt(input);
        if (isNaN(parsed)) {
            text.set_text(input.substr(0, input.length - 1));
            parsed = 0;
        }
        callback(parsed);
    });
    const item = new PopupMenuItem(label);
    item.label.get_clutter_text().set_x_expand(true);
    item.label.set_y_align(Clutter.ActorAlign.CENTER);
    item.add_child(entry);
    return item;
}
function parse_number(text) {
    let number = parseInt(text, 10);
    if (isNaN(number)) {
        number = 0;
    }
    return number;
}
function show_title(ext) {
    const t = toggle(_("Show Window Titles"), ext.settings.show_title(), (toggle) => {
        ext.settings.set_show_title(toggle.state);
    });
    return t;
}
function toggle(desc, active, connect) {
    let toggle = new PopupSwitchMenuItem(desc, active);
    toggle.label.set_y_align(Clutter.ActorAlign.CENTER);
    toggle.connect('toggled', () => {
        connect(toggle);
        return true;
    });
    return toggle;
}
function tiled(ext) {
    let t = toggle(_("Tile Windows"), null != ext.auto_tiler, () => ext.toggle_tiling());
    return t;
}
function color_selector(ext, menu) {
    let color_selector_item = new PopupMenuItem('Active Hint Color');
    let color_button = new St.Button();
    let settings = ext.settings;
    let selected_color = settings.hint_color_rgba();
    color_button.label = "           ";
    color_button.set_style(`background-color: ${selected_color}; border: 2px solid lightgray; border-radius: 2px`);
    settings.ext.connect('changed', (_, key) => {
        if (key === 'hint-color-rgba') {
            let color_value = settings.hint_color_rgba();
            color_button.set_style(`background-color: ${color_value}; border: 2px solid lightgray; border-radius: 2px`);
        }
    });
    color_button.set_x_align(Clutter.ActorAlign.END);
    color_button.set_x_expand(false);
    color_selector_item.label.get_clutter_text().set_x_expand(true);
    color_selector_item.label.set_y_align(Clutter.ActorAlign.CENTER);
    color_selector_item.add_child(color_button);
    color_button.connect('button-press-event', () => {
        let path = Me.dir.get_path() + "/color_dialog/main.js";
        let resp = GLib.spawn_command_line_async(`gjs ${path}`);
        if (!resp) {
            return null;
        }
        GLib.timeout_add(GLib.PRIORITY_LOW, 300, () => {
            menu.close();
            return false;
        });
    });
    return color_selector_item;
}
